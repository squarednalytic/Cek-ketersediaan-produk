<?php require PATH_PAGES . "TEMPLATE-top.php"; ?>
<h1>NOT FOUND</h1>
<p>It may have been abducted by aliens.</p>
<?php require PATH_PAGES . "TEMPLATE-bottom.php"; ?>